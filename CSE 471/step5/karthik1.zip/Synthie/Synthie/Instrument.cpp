#include "stdafx.h"
#include "Instrument.h"


CInstrument::CInstrument()
{
}


CInstrument::~CInstrument()
{
}
