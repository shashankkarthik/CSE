//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Synthie.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_SynthieTYPE                 130
#define IDD_PROGRESS_DLG                131
#define IDS_EDIT_MENU                   306
#define IDC_PROGRESS                    1000
#define IDC_STOP                        1001
#define ID_GENERATE_FILEOUTPUT          32771
#define ID_GENERATE_AUDIOOUTPUT         32772
#define ID_GENERATE_1000HZTONE          32773
#define ID_GENERATE_SYNTHESIZER         32774
#define ID_FILE_OPENSCORE               32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
