//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ImageProcess.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BITMAPTYPE                  129
#define IDR_PROCESSMENU                 129
#define IDS_NOT_DIB                     130
#define IDR_GENERATEMENU                130
#define IDS_CANNOT_LOAD_DIB             132
#define ID_FILE_SAVESPECIAL             132
#define IDS_CANNOT_SAVE_DIB             133
#define IDD_CARTMANDLG                  133
#define IDS_UNSUPPORTED_DIB             134
#define ID_MOUSE_CARTMANPARAMETERS      134
#define IDS_PREMATURE_EOF_DIB           135
#define IDS_NO_DIB                      136
#define IDS_NOT_A_DIB                   137
#define IDC_NEAREST                     1007
#define IDC_CHECK2                      1008
#define IDC_TRANSPARENT                 1008
#define ID_FILTER_NEGATIVE              32790
#define ID_FILTER_COPY                  32791
#define ID_MOUSE_DRAW                   32792
#define ID_MOUSE_THRESHOLD              32793
#define ID_MOUSE_CARTMAN                32794
#define ID_FILE_NEWEMPTYIMAGE           32795
#define ID_NEWEMPTYIMAGE_               32796
#define ID_GENERATE_FILLWHITE           32797
#define ID_FILE_NEWEMPTYIMAGE32798      32798
#define ID_FILE_NEWEMPTYIMAGE32799      32799
#define ID_FILTER_ENHANCE               32800
#define ID_GENERATE_FILLGREEN           32801
#define ID_FILTER_DIM                   32802
#define ID_FILTER_TINT                  32803
#define ID_FILTER_LOWPASSFILTER         32804
#define ID_FILTER_DIMGREY               32805
#define ID_GENERATE_FILLDIMGREY         32806
#define ID_FILTER_HORIZONTALGRADIENT    32807
#define ID_GENERATE_HORIZONTALGRADIENT  32808
#define ID_GENERATE_VERTICALBLUEGRADIENT 32809
#define ID_GENERATE_DIAGONALGRADIENT    32810
#define ID_GENERATE_HORIZONTALLINE      32811
#define ID_GENERATE_VERTICALLINE        32812
#define ID_GENERATE_DIAGONALLINE        32813
#define ID_FILTER_MONOCHROME            32814
#define ID_FILTER_3X3MEDIAN             32815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32816
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
