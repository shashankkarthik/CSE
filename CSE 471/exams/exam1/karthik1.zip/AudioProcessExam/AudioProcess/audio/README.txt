Necessary libraries:  

amstrmid.lib quartz.lib dsound.lib dxguid.lib
