#ifndef KTHSMALLEST_H_
#define KTHSMALLEST_H_


#include <iostream>
#include <ctime>
#include <cmath>
#include <vector>
#include <algorithm>
#include <chrono>
using namespace std;
template <typename Comparable>
void  print(const vector<Comparable> &nums)
{
	cout<< "Vector Contents " << endl<<endl;
	int temp2=0;
	for (int i=0; i< nums.size(); i++)
	{
		temp2=nums[i];
		cout<< "["<<i<<"]"<<" --> " << temp2<< endl;
	}

}
template <typename Comparable>
void printkth(const vector<Comparable> &nums, int kth)
{
	int temp2=0;
	temp2= nums[kth-1];
	if (kth ==1)
	 cout<< kth<< " st smallest value in vector -->  " << temp2<< endl;
	else if(kth==2)
		cout<<kth<<" nd smallest value in vector -->  "<< temp2<<endl;
	else if(kth==3)
		cout<<kth<<" rd smallest value in vector -->  "<< temp2<<endl;

	else
		cout<< kth<< " th smallest value in vector -->  " << temp2<< endl;

        cout<<endl<<endl;
	}

template <typename Comparable>
void insertionSort(vector<Comparable> &a, int kth)
{
   //your code goes here  
   //you can add helper methods can be called from this method..
   printkth(a,kth);
}



template <typename Comparable>
void  kthSmallest(const vector<Comparable> &nums, int kthvalue)
{
    //your code goes here
    printkth(nums,kthvalue);
}



#endif /* KTHSMALLEST_H_ */

