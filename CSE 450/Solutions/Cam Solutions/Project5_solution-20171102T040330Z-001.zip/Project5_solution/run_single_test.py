#!/usr/bin/env python3
"""
The purpose of this module is to run a single test associated
with a project.
"""

import argparse
import traceback
import os
import subprocess
import sys

# Number of seconds before killing command
TEST_TIMEOUT = 2


def remove(filename):
    if os.path.exists(filename):
        os.remove(filename)


class TestRunnerException(Exception):
    """
    Exception used to distinguish if the test runner failed.
    """
    pass


def get_output(executable_args, test_file, ic_output):
    """
    Converts the test_file (file handle) to the
    student's project output (string).
    """
    output = []
    output_path = os.path.join(os.getcwd(), "temp.tic")
    remove(output_path)
    args = executable_args + [test_file.name, output_path]

    try:
        stdout = subprocess.check_output(args,
                                         stderr=subprocess.STDOUT,
                                         universal_newlines=True,
                                         # input=contents,
                                         timeout=TEST_TIMEOUT)
        output.append(stdout)
    except subprocess.CalledProcessError as cpe:
        # output.append(cpe.output)
        output.append("Non-Zero Return Code")
    except subprocess.TimeoutExpired as te:
        output = ["TestRunner: Command took too long, killing it."]
    except Exception as e:
        output.append("Exception Raised!!!")
        output.append(traceback.format_exc())
    if not os.path.exists(output_path):
        output.append("No Intermediate Code File Created")
    else:
        if ic_output:
            output.append(open(output_path, "r").read())
        else:
            run_generated_ic(output, output_path)
    remove(output_path)
    return "\n".join(output) + "\n"


def run_generated_ic(output, ic_path):
    try:
        stdout = subprocess.check_output(["../ReferenceCode/TubeIC", ic_path],
                                         stderr=subprocess.STDOUT,
                                         universal_newlines=True,
                                         timeout=TEST_TIMEOUT / 2)
        output.append("Executed Intermediate Code Output:")
        output.append(stdout)
    except subprocess.CalledProcessError as cpe:
        output.append("Non-Zero Return Code From TubeIC")
    except subprocess.TimeoutExpired as te:
        output.append("TestRunner: TubeIC took too long, killing it.")


def get_input(test_file):
    """
    Returns the contents of the test.
    """
    return test_file.read()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="""
    Runs a single test.
    If no arguments (apart from the test filename) are given,
    it outputs your project's test output.
    """)
    parser.add_argument('test_file', type=argparse.FileType('r'),
                        help="The file containing the test contents.")
    parser.add_argument('output_file', nargs='?', type=argparse.FileType('w'),
                        default=sys.stdout, help="""The file to write the output of this program to.
If not given, outputs to stdout.""")
    parser.add_argument('--correct', action='store_true', help="""
    If given, outputs the correct output for a test.""")
    parser.add_argument('--input', action='store_true', help="""
    If given, outputs the project's output for a test.""")
    parser.add_argument('--ic', action='store_true', help="""
    If given, outputs the intermediate code instead of the executed output.""")

    args = parser.parse_args()

    if args.correct:
        output = get_output(["../ReferenceCode/project5_ic_compiler"],
                            args.test_file, args.ic)
    elif args.input:
        output = get_input(args.test_file)
    else:
        output = get_output(["python3", "ic_compiler.py"],
                            args.test_file,
                            args.ic)

    args.output_file.write(output)
