#! /usr/bin/env python3
import sys
import argparse
import my_parser as parser

IC_INSTRUCTIONS = []


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("tubular_source_path",
                        help="The path to the Tubular (.tube) file.")
    parser.add_argument("tic_output_path",
                        help="The path to the TubeIC (.tic) file.")
    parser.add_argument("--debug", action='store_true',
                        help="Debug Mode")
    return parser.parse_args()


if __name__ == "__main__":
    args = get_args()
    if args.debug:
        print("Debug Mode!")

    parse_tree = parser.parse(args.tubular_source_path, args.debug)

    if args.debug:
        with open("debug_ast.txt", "w") as handle:
            handle.write(str(parse_tree))
    parse_tree.generate_ic(IC_INSTRUCTIONS)
    ic = "\n".join(IC_INSTRUCTIONS) + "\n"
    with open(args.tic_output_path, "w") as handle:
        handle.write(ic)
